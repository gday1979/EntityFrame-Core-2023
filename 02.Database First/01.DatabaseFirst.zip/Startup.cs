﻿namespace SoftUni
{
    public class Startup
    {
        static void Main(string[] args)
        {
            
        }
    }
}